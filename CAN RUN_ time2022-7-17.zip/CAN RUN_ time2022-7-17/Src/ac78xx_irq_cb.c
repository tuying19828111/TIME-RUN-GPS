/**
  ******************************************************************************
  * @file    ac78xx_irq_cb.c
  * @brief   IRQ callback.
  ******************************************************************************
  * This software/firmware and related documentation ("AutoChips Software") are
  * protected under relevant copyright laws. The information contained herein is
  * confidential and proprietary to AutoChips Inc. and/or its licensors. Without
  * the prior written permission of AutoChips inc. and/or its licensors, any
  * reproduction, modification, use or disclosure of AutoChips Software, and
  * information contained herein, in whole or in part, shall be strictly
  * prohibited.
  *
  * AutoChips Inc. (C) 2022. All rights reserved.
  *
  * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
  * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("AUTOCHIPS SOFTWARE")
  * RECEIVED FROM AUTOCHIPS AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
  * ON AN "AS-IS" BASIS ONLY. AUTOCHIPS EXPRESSLY DISCLAIMS ANY AND ALL
  * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
  * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
  * NONINFRINGEMENT. NEITHER DOES AUTOCHIPS PROVIDE ANY WARRANTY WHATSOEVER WITH
  * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
  * INCORPORATED IN, OR SUPPLIED WITH THE AUTOCHIPS SOFTWARE, AND RECEIVER AGREES
  * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
  * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
  * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN AUTOCHIPS
  * SOFTWARE. AUTOCHIPS SHALL ALSO NOT BE RESPONSIBLE FOR ANY AUTOCHIPS SOFTWARE
  * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
  * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND AUTOCHIPS'S
  * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE AUTOCHIPS SOFTWARE
  * RELEASED HEREUNDER WILL BE, AT AUTOCHIPS'S OPTION, TO REVISE OR REPLACE THE
  * AUTOCHIPS SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
  * CHARGE PAID BY RECEIVER TO AUTOCHIPS FOR SUCH AUTOCHIPS SOFTWARE AT ISSUE.
  *
  ******************************************************************************  
  */
/* --------------------------------- Includes ---------------------------------*/
#include "ac78xx.h"
#include "ac78xx_irq_cb.h"
#include "ac78xx_uart.h"
#include "ac78xx_timer.h"
#include "ac78xx_can.h"
/* USER CODE BEGIN Includes */
#include "main.h"
#include "timer.h"
/* USER CODE END Includes */

/* --------------------------------- Typedefs ----------------------------------*/
/* USER CODE BEGIN Typedefs */
uint8_t i,j,m;
CAN_MSG_INFO  CAN2_TecvCANMsg;
CAN_MSG_INFO  CAN2_RecvCANMsg; 
CAN_MSG_INFO  CAN1_TecvCANMsg;
CAN_MSG_INFO  CAN1_RecvCANMsg;
#define       CAN_SEND_DATA_ID501 	  	(0x00000501)//����������
//һ������ First level locking{0x46, 0x69, 0x72, 0x73, 0x74, 0x20, 0x6C, 0x65, 0x76, 0x65, 0x6C, 0x20, 0x6C, 0x6F, 0x63, 0x6B, 0x69, 0x6E, 0x67}
char		UART_RrcvDataBuf_1        []= "First level locking";
uint8_t				CAN_TecvDataBuf_1         [8] = {0x00, 0x03, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};//һ������
//�������� Secondary locking{0x53, 0x65, 0x63, 0x6F, 0x6E, 0x64, 0x61, 0x72, 0x79, 0x20, 0x6C, 0x6F, 0x63, 0x6B, 0x69, 0x6E, 0x67}
char		UART_RrcvDataBuf_2        []= "Secondary locking";
uint8_t				CAN_TecvDataBuf_2         [8] = {0x00, 0x03, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00};//��������
//������� Release the lock{0x52, 0x65, 0x6C, 0x65, 0x61, 0x73, 0x65, 0x20, 0x74, 0x68, 0x65, 0x20, 0x6C, 0x6F, 0x63, 0x6B}
char		UART_RrcvDataBuf_UN       []= "Release the lock";
uint8_t				CAN_TecvDataBuf_UN        [8] = {0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};//����

#define       CAN_SEND_DATA_ID504			  (0x00000504)//��������������
uint8_t				CAN_RecvDataBuf_2_return  [8] = {0x00, 0x05, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00};//������������
uint8_t				CAN_RecvDataBuf_1_return  [8] = {0x00, 0x05, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};//һ����������
uint8_t				CAN_RecvDataBuf_UN_return [8] = {0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};//��������

#define       CAN_SEND_DATA_ID502		  	(0x00000502)//�رա���GPS���
//������� Turn on monitoring { 0x54, 0x75, 0x72, 0x6E, 0x20, 0x6F, 0x6E, 0x20, 0x6D, 0x6F, 0x6E, 0x69, 0x74, 0x6F, 0x72, 0x69, 0x6E, 0x67}
char		UART_RrcvDataBuf_ON_gps   []= "Turn on monitoring";
uint8_t				CAN_TecvDataBuf_ON_gps    [8] = {0x02, 0x06, 0x02, 0x00, 0x00, 0x00, 0x00, 0x00};//��GPS
//�رռ�� Turn off monitoring { 0x54, 0x75, 0x72, 0x6E, 0x20, 0x6F, 0x66, 0x66, 0x20, 0x6D, 0x6F, 0x6E, 0x69, 0x74, 0x6F, 0x72, 0x69, 0x6E, 0x67} 
char		UART_RrcvDataBuf_OFF_gps  []= "Turn off monitoring";
uint8_t				CAN_TecvDataBuf_OFF_gps   [8] = {0x01, 0x04, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00};//�ر�GPS

#define       CAN_SEND_DATA_ID503			  (0x00000503)//�رա���GPS����
uint8_t				CAN_RecvDataBuf_ON_return [8] = {0x02, 0x03, 0x05, 0x00, 0x00, 0x00, 0x00, 0x00};//��GPS����
uint8_t				CAN_RecvDataBuf_OFF_return[8] = {0x01, 0x02, 0x03, 0x00, 0x00, 0x00, 0x00, 0x00};//�ر�GPS����

char		UART_RrcvDataBuf_Run   []= "LC:E9157472\r\n";//�����ܱ�����
char		UART_RrcvDataBuf_Stop  []= "LC:E9157876\r\n";//�ر��ܱ�����
char		UART_RrcvDataBuf_Run1  []= "LC:23CD6454\r\n";//�����ܱ�����
char		UART_RrcvDataBuf_Stop1 []= "LC:23CD6252\r\n";//�ر��ܱ�����
//�ܱ����ֱ���
#define CAN_SEND_DATA_ID200			(0x00000200)
#define CAN_SEND_DATA_ID201			(0x00000201)
#define CAN_SEND_DATA_ID202			(0x00000202)
#define CAN_SEND_DATA_ID203			(0x00000203)
#define CAN_SEND_DATA_ID204			(0x00000204)
#define CAN_SEND_DATA_IDF20			(0x00000F20)
#define CAN_SEND_DATA_IDF30			(0x00000F30)
#define CAN_SEND_DATA_IDF99			(0x00000F99)

uint8_t					CAN_RECVDataBuf_200[8] = {0x28, 0x01, 0x31, 0x00, 0xE8, 0x03, 0xE8, 0x03};
uint8_t					CAN_RECVDataBuf_201[8] = {0x89, 0x00, 0x01, 0x00, 0x9f, 0x00, 0x00, 0x00};
uint8_t					CAN_RECVDataBuf_202[8] = {0x46, 0x00, 0x35, 0x00, 0xA9, 0x00, 0xC6, 0x00};
uint8_t					CAN_RECVDataBuf_203[8] = {0x31, 0x00, 0x46, 0x00, 0x4A, 0x00, 0x1E, 0x00};
uint8_t					CAN_RECVDataBuf_204[8] = {0xB8, 0x27, 0x7D, 0x00, 0x8C, 0x07, 0x84, 0x00};
uint8_t					CAN_RECVDataBuf_F20[8] = {0x04, 0x05, 0x05, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
uint8_t					CAN_RECVDataBuf_F30[8] = {0x66, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
uint8_t					CAN_RECVDataBuf_F31[8] = {0xAA, 0x00, 0x00, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
uint8_t					CAN_RECVDataBuf_F99[8] = {0x22, 0x16, 0x0A, 0x21, 0x01, 0x21, 0x01, 0x02};
uint8_t RxBuff=0;
char		DataBuff[30];
uint8_t RxLine=0;
static uint8_t F_30=0;
int8_t can_1=0;
uint8_t can_2=0;
uint8_t can_UN=0;
uint8_t can_ON=0;
uint8_t can_OFF=0;
#define LED_Delay1s   96000000-1
#define LED_Delay500m 48000000-1
#define LED_Delay250m 24000000-1
#define LED_Delay100m 9600000-1
/* USER CODE END Typedefs */

/* --------------------------------- Defines -----------------------------------*/
/* USER CODE BEGIN Defines */
 
/* USER CODE END Defines */

/* --------------------------------- Macros ------------------------------------*/
/* USER CODE BEGIN Macros */

/* USER CODE END Macros */

/* --------------------------------- Variables ---------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */

/* --------------------------------- Function Prototypes -----------------------*/
/* USER CODE BEGIN Function_Prototypes */

/* USER CODE END Function_Prototypes */

/* --------------------------------- User Code ---------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/******************************************************************************/
/* ac78xx Peripheral Interrupt Handlers callbacks                             */
/******************************************************************************/

/**
* @brief This function handle UART1 interrupt.
* @return 0: success, other: error value
*/
int32_t UART1_IRQHandler_Callback(uint8_t port, uint32_t lsr0, uint32_t lsr1)
{
    if ((UART1->UARTn_IER.ERXNE == 1) && (lsr0 & LSR0_DR))
    {
        /* USER CODE BEGIN UART1 RECEIVE DATA */
			if (!RxBuff)//��������
				{
				DataBuff[RxLine++] = UART_ReceiveData(UART1);
				}
        /* USER CODE END UART1 RECEIVE DATA */
    }
    if ((UART1->UARTn_IER.ETXE == 1) && (lsr0 & LSR0_THRE))
    {
        /* USER CODE BEGIN UART1 SEND DATA */

        /* USER CODE END UART1 SEND DATA */
    }

    /* USER CODE BEGIN UART1_IRQHandler_Callback*/

    /* USER CODE END UART1_IRQHandler_Callback*/
    return 0;
}

/**
* @brief This function handle UART3 interrupt.
* @return 0: success, other: error value
*/
int32_t UART3_IRQHandler_Callback(uint8_t port, uint32_t lsr0, uint32_t lsr1)
{
    if ((UART3->UARTn_IER.ERXNE == 1) && (lsr0 & LSR0_DR))
    {
        /* USER CODE BEGIN UART3 RECEIVE DATA */
			if (!RxBuff)//��������
				{
				DataBuff[RxLine++] = UART_ReceiveData(UART3);
				}
        /* USER CODE END UART3 RECEIVE DATA */
    }
    if ((UART3->UARTn_IER.ETXE == 1) && (lsr0 & LSR0_THRE))
    {
        /* USER CODE BEGIN UART3 SEND DATA */

        /* USER CODE END UART3 SEND DATA */
    }

    /* USER CODE BEGIN UART3_IRQHandler_Callback*/

    /* USER CODE END UART3_IRQHandler_Callback*/
    return 0;
}

/**
* @brief This function handle Timer 0 interrupt.
* @param[in] arg: timer callback argument
* @return none
*/
void TIMER0_IRQHandler_Callback(uint8_t arg)
{
    TIMER_ClrIntFlag(TIMER_GetTimerCtrl(arg));

    /* USER CODE BEGIN TIMER0_IRQHandler_Callback*/
		LED_TOGGLE;
    /* USER CODE END TIMER0_IRQHandler_Callback*/
}

/**
* @brief This function handle Timer 1 interrupt.
* @param[in] arg: timer callback argument
* @return none
*/
void TIMER1_IRQHandler_Callback(uint8_t arg)
{
    TIMER_ClrIntFlag(TIMER_GetTimerCtrl(arg));

    /* USER CODE BEGIN TIMER1_IRQHandler_Callback*/
	if(F_30<3)
		{
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_IDF30;
//			CAN1_TecvCANMsg .IDE=1;
//			CAN1_TecvCANMsg .RTR=0;
//			CAN1_TecvCANMsg .DLC=8;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
			{
			CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_F30[i];
			}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			F_30=5;
		}
		else 
		{
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_IDF30;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
			{
			CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_F31[i];
			}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			F_30=2;
		}
    /* USER CODE END TIMER1_IRQHandler_Callback*/
}

/**
* @brief This function handle CAN 1 interrupt.
* @param[in] event: can event
* @param[in] wparam: reserved
* @param[in] lparam: reserved
* @return 0: success, other: error value
*/
int32_t CAN1_IRQHandler_Callback(uint32_t event, uint32_t wparam, uint32_t lparam)
{
	if (event & CAN_EVENT_RECVMSG)
	{
			/* USER CODE BEGIN CAN1 EVENT RECEIVE MESSAGE */
	 if (CAN_IsMsgInReceiveBuf((CAN_Type*)lparam))
		{
			CAN_MessageRead((CAN_Type*)lparam, &CAN1_RecvCANMsg);
			if(CAN1_RecvCANMsg.ID==0x00000504)
				{
					if((CAN1_RecvCANMsg .Data[1]==0x05)&&(CAN1_RecvCANMsg .Data[2]==0x01))
					{
						can_1=2;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN1_RecvCANMsg.ID==0x00000504)
				{
					if((CAN1_RecvCANMsg .Data[1]==0x05)&&(CAN1_RecvCANMsg .Data[2]==0x02))
					{
						can_2=3;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN1_RecvCANMsg.ID==0x00000504)
				{
					if((CAN1_RecvCANMsg .Data[1]==0x08)&&(CAN1_RecvCANMsg .Data[2]==0x00))
					{
						can_UN=4;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN1_RecvCANMsg.ID==0x00000503)
				{
					if((CAN1_RecvCANMsg .Data[1]==0x02)&&(CAN1_RecvCANMsg .Data[2]==0x03))
					{
						can_OFF=5;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN1_RecvCANMsg.ID==0x00000503)
				{
					if((CAN1_RecvCANMsg .Data[1]==0x03)&&(CAN1_RecvCANMsg .Data[2]==0x05))
					{
						can_ON=6;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			}
        /* USER CODE END CAN1 EVENT RECEIVE MESSAGE */
    }

    /* USER CODE BEGIN CAN1_IRQHandler_Callback*/

    /* USER CODE END CAN1_IRQHandler_Callback*/
    return 0;
}

/**
* @brief This function handle CAN 2 interrupt.
* @param[in] event: can event
* @param[in] wparam: reserved
* @param[in] lparam: reserved
* @return 0: success, other: error value
*/
int32_t CAN2_IRQHandler_Callback(uint32_t event, uint32_t wparam, uint32_t lparam)
{
	if (event & CAN_EVENT_RECVMSG)
	{
			/* USER CODE BEGIN CAN2 EVENT RECEIVE MESSAGE */
		if (CAN_IsMsgInReceiveBuf((CAN_Type*)lparam))
		{
			CAN_MessageRead((CAN_Type*)lparam, &CAN2_RecvCANMsg);
			if(CAN2_RecvCANMsg.ID==0x00000504)
				{
					if((CAN2_RecvCANMsg .Data[1]==0x05)&&(CAN2_RecvCANMsg .Data[2]==0x01))
					{
						can_1=2;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN2_RecvCANMsg.ID==0x00000504)
				{
					if((CAN2_RecvCANMsg .Data[1]==0x05)&&(CAN2_RecvCANMsg .Data[2]==0x02))
					{
						can_2=3;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN2_RecvCANMsg.ID==0x00000504)
				{
					if((CAN2_RecvCANMsg .Data[1]==0x08)&&(CAN2_RecvCANMsg .Data[2]==0x00))
					{
						can_UN=4;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN2_RecvCANMsg.ID==0x00000503)
				{
					if((CAN2_RecvCANMsg .Data[1]==0x02)&&(CAN2_RecvCANMsg .Data[2]==0x03))
					{
						can_OFF=5;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			if(CAN2_RecvCANMsg.ID==0x00000503)
				{
					if((CAN2_RecvCANMsg .Data[1]==0x03)&&(CAN2_RecvCANMsg .Data[2]==0x05))
					{
						can_ON=6;
						TIMER_SetLoadVal(TIMER0, LED_Delay500m);
					}
				}
			}
        /* USER CODE END CAN2 EVENT RECEIVE MESSAGE */
    }

    /* USER CODE BEGIN CAN2_IRQHandler_Callback*/

    /* USER CODE END CAN2_IRQHandler_Callback*/
    return 0;
}

/**
* @brief This function handle TIMER 2 interrupt.
* @param[in] arg: timer callback argument
* @return none
*/
void TIMER2_IRQHandler_Callback(uint8_t arg)
{
    TIMER_ClrIntFlag(TIMER_GetTimerCtrl(arg));

    /* USER CODE BEGIN TIMER2_IRQHandler_Callback*/
		CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID200;
		for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
		{
		CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_200[i];
		}
		CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		
		CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID201;
		for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
		{
		CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_201[i];
		}
		CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		
		CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID202;
		for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
		{
		CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_202[i];
		}
		CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);

		CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID203;
		for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
		{
		CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_203[i];
		}
		CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		
		CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID204;
		for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
		{
		CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_204[i];
		}
		CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
    /* USER CODE END TIMER2_IRQHandler_Callback*/
}

/**
* @brief This function handle TIMER 3 interrupt.
* @param[in] arg: timer callback argument
* @return none
*/
void TIMER3_IRQHandler_Callback(uint8_t arg)
{
    TIMER_ClrIntFlag(TIMER_GetTimerCtrl(arg));

    /* USER CODE BEGIN TIMER3_IRQHandler_Callback*/
		CAN1_TecvCANMsg .ID =CAN_SEND_DATA_IDF99;
		for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
		{
		CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_F99[i];
		}
		CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		
		CAN1_TecvCANMsg .ID =CAN_SEND_DATA_IDF20;
		for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
		{
		CAN1_TecvCANMsg .Data[i]=CAN_RECVDataBuf_F20[i];
		}
		CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
		CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
    /* USER CODE END TIMER3_IRQHandler_Callback*/
}

/* USER CODE BEGIN 1 */
void CAN_TECV_msg(void )
{
	CAN1_TecvCANMsg .IDE=1;
	CAN1_TecvCANMsg .RTR=0;
	CAN1_TecvCANMsg .DLC=8;
	if(strcmp(DataBuff, UART_RrcvDataBuf_1) == 0)//һ������
	{
		while (can_1 <2)
		{		
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID501;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
			{CAN1_TecvCANMsg .Data[i]=CAN_TecvDataBuf_1[i];}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			TIMER_SetLoadVal(TIMER0, LED_Delay100m);
			mdelay (100);
		}
	}
	if (strcmp(DataBuff, UART_RrcvDataBuf_2) == 0)//һ������
	{
		while (can_2<3)
		{		
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID501;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
			{CAN1_TecvCANMsg .Data[i]=CAN_TecvDataBuf_2[i];}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			TIMER_SetLoadVal(TIMER0, LED_Delay100m);	
			mdelay (100);			
		}
	}
	if (strcmp(DataBuff, UART_RrcvDataBuf_UN) == 0)//����
	{
		while (can_UN<4)
		{		
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID501;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
			{CAN1_TecvCANMsg .Data[i]=CAN_TecvDataBuf_UN[i];}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			TIMER_SetLoadVal(TIMER0, LED_Delay100m);
			mdelay (100);
		}
	}
	if (strcmp(DataBuff, UART_RrcvDataBuf_ON_gps) == 0)//��GPS
	{
		while (can_ON<6)
		{		
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID502;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
				{CAN1_TecvCANMsg .Data[i]=CAN_TecvDataBuf_ON_gps[i];}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
						
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID503;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
				{CAN1_TecvCANMsg .Data[i]=CAN_RecvDataBuf_ON_return[i];}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			TIMER_SetLoadVal(TIMER0, LED_Delay100m);
			mdelay (100);
		}
	}
	if (strcmp(DataBuff, UART_RrcvDataBuf_OFF_gps) == 0)//�ر�GPS
	{
		while (can_OFF<5)
		{		
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID502;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
				{CAN1_TecvCANMsg .Data[i]=CAN_TecvDataBuf_OFF_gps[i];}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			
			CAN1_TecvCANMsg .ID =CAN_SEND_DATA_ID503;
			for(i=0;i<8;i++)//8��ѭ����CAN1�յ������ݸ�ֵ��CAN2
				{CAN1_TecvCANMsg .Data[i]=CAN_RecvDataBuf_OFF_return[i];}
			CAN_MessageSend(CAN1, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			CAN_MessageSend(CAN2, &CAN1_TecvCANMsg, TRANSMIT_PRIMARY);
			TIMER_SetLoadVal(TIMER0, LED_Delay100m);
			mdelay (100);
		}
	}	
	if (strcmp(DataBuff, UART_RrcvDataBuf_Run) == 0||strcmp(DataBuff, UART_RrcvDataBuf_Run1) == 0)//�����ܱ�����
	{
    ATC_TIMER1_Init();
    ATC_TIMER2_Init();
    ATC_TIMER3_Init();
		TIMER_SetLoadVal(TIMER0, LED_Delay250m);
		GPIO_SetPinValue(JDQ_1_Pin , GPIO_LEVEL_HIGH);
	}	
	if (strcmp(DataBuff, UART_RrcvDataBuf_Stop) == 0||strcmp(DataBuff, UART_RrcvDataBuf_Stop1) == 0)//�����ܱ�����
	{
		TIMER_DeInit(TIMER1);
		TIMER_DeInit(TIMER2);
		TIMER_DeInit(TIMER3);
		TIMER_SetLoadVal(TIMER0, LED_Delay500m);
		GPIO_SetPinValue(JDQ_1_Pin , GPIO_LEVEL_LOW);
	}

	memset(DataBuff,0,sizeof(DataBuff));  //��ջ�������
	RxLine=0;	can_1=0;can_2=0;can_UN=0;can_ON=0;can_OFF=0;
}

/* USER CODE END 1 */
/************************ (C) COPYRIGHT AutoChips *****END OF FILE****/
